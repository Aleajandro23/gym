from django.apps import AppConfig

class GimnasioAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gimnasio_app'
