from django.db import models

class Gimnasio(models.Model):
    nombre = models.CharField(max_length=100)
    ciudad = models.CharField(max_length=100)
    max_socios = models.IntegerField()
    contacto = models.CharField(max_length=20)

    def __str__(self):
        return self.nombre

class PlanEntrenamiento(models.Model):
    PLAN_CHOICES = [
        ('musculacion', 'Musculación'),
        ('perdida_peso', 'Pérdida de peso'),
        ('funcional', 'Entrenamiento funcional'),
    ]
    nombre = models.CharField(max_length=50, choices=PLAN_CHOICES)
    duracion_semanas = models.IntegerField()
    costo = models.DecimalField(max_digits=8, decimal_places=2)
    gimnasio = models.ForeignKey(Gimnasio, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.get_nombre_display()} - {self.gimnasio.nombre}"
