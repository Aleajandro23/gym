from django.contrib import admin
from .models import Gimnasio, PlanEntrenamiento
admin.site.register(Gimnasio)
admin.site.register(PlanEntrenamiento)
