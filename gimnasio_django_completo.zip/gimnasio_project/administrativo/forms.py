from django import forms
from .models import Gimnasio, PlanEntrenamiento

class GimnasioForm(forms.ModelForm):
    class Meta:
        model = Gimnasio
        fields = '__all__'

class PlanForm(forms.ModelForm):
    class Meta:
        model = PlanEntrenamiento
        fields = '__all__'
