from django.shortcuts import render, redirect
from .models import Gimnasio, PlanEntrenamiento
from .forms import GimnasioForm, PlanForm

def inicio(request):
    return render(request, 'administrativo/inicio.html')

def lista_gimnasios(request):
    gimnasios = Gimnasio.objects.all()
    return render(request, 'administrativo/listar_gimnasios.html', {'gimnasios': gimnasios})

def crear_gimnasio(request):
    form = GimnasioForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('lista_gimnasios')
    return render(request, 'administrativo/formulario.html', {'form': form, 'titulo': 'Nuevo Gimnasio'})

def lista_planes(request):
    planes = PlanEntrenamiento.objects.all()
    return render(request, 'administrativo/listar_planes.html', {'planes': planes})

def crear_plan(request):
    form = PlanForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('lista_planes')
    return render(request, 'administrativo/formulario.html', {'form': form, 'titulo': 'Nuevo Plan'})
