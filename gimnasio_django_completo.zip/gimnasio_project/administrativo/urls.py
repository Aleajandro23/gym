from django.urls import path
from . import views

urlpatterns = [
    path('', views.inicio, name='inicio'),
    path('gimnasios/', views.lista_gimnasios, name='lista_gimnasios'),
    path('gimnasios/nuevo/', views.crear_gimnasio, name='crear_gimnasio'),
    path('planes/', views.lista_planes, name='lista_planes'),
    path('planes/nuevo/', views.crear_plan, name='crear_plan'),
]
